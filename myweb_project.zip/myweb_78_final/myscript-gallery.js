var bigPic = document.querySelector("#big");           //큰 사진 요소
var smallPics = document.querySelectorAll(".picture"); //작은 사진 요소
  
for(let i = 0; i < smallPics.length; i++) {            //클릭시 이벤트 설정
  smallPics[i].addEventListener("click", changePic);
}

function changePic() {
  var newPic = this.src;
  bigPic.setAttribute("src", newPic);                  //큰 사진으로 변경
}
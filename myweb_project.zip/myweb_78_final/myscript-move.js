// 모든 버튼 요소를 가져옵니다.
const scrollButtons = document.querySelectorAll('.nav-btn');

// 각 버튼에 대해 클릭 이벤트 리스너를 추가합니다.
scrollButtons.forEach(button => {
    button.addEventListener('click', function() {
        // 클릭된 버튼의 data-target 속성값을 가져옵니다.
        const targetId = button.getAttribute('data-target');
        // 해당 ID를 가진 요소를 찾아서 스크롤합니다.
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
            targetElement.scrollIntoView({ behavior: 'smooth' });
        }
    });
});



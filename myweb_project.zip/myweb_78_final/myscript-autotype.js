let target = document.querySelector("#autotype");

function dynamic(stringArr) {
    if (stringArr.length > 0) {         //출력할 문자열 배열이 있는지 확인
        target.textContent += stringArr.shift();  //한 글자씩 꺼내서 문장 만들기
        setTimeout(function(){         //100밀리초 간격으로 자신 호출 
            dynamic(stringArr); 
        }, 100);
    } else {
        setTimeout(resetTyping, 1000);  //문자열을 다 출력하고 1초 후 다시
    }
}

function resetTyping() {
    target.textContent = "";            //완성된 문장 비우기
    dynamic(insaMAL.split(""));         //문자열 배열 초기화
}

var insaMAL = document.getElementById("autotype").innerHTML;
target.textContent = "";    //출력 문장 초기화
dynamic(insaMAL.split("")); //문자열을 배열로 변환하여 dynamic 함수 호출